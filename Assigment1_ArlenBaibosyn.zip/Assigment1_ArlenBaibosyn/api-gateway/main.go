package main

import (
	"io"
	"net/http"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()

	// Enable CORS with custom configuration
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"http://127.0.0.1:5500", "http://localhost:5500"},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE"},
		AllowHeaders:     []string{"Origin", "Content-Type"},
		ExposeHeaders:    []string{"Content-Length"},
		AllowCredentials: true,
		MaxAge:           12 * time.Hour,
	}))

	r.GET("/", func(c *gin.Context) {
		c.Writer.Write([]byte(`
			<html><body>
				<h1>Microservices Gateway</h1>
				<a href="/inventory/products">View Products</a><br>
				<a href="/orders">View Orders</a>
			</body></html>
		`))
	})

	r.GET("/inventory/products", func(c *gin.Context) {
		resp, err := http.Get("http://localhost:8081/products")
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		c.Data(resp.StatusCode, "application/json", body)
	})

	r.POST("/inventory/products", func(c *gin.Context) {
		resp, err := http.Post("http://localhost:8081/products", "application/json", c.Request.Body)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		c.Data(resp.StatusCode, "application/json", body)
	})

	r.DELETE("/inventory/products/:id", func(c *gin.Context) {
		req, err := http.NewRequest("DELETE", "http://localhost:8081/products/"+c.Param("id"), nil)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		c.Data(resp.StatusCode, "application/json", body)
	})

	r.GET("/orders", func(c *gin.Context) {
		resp, err := http.Get("http://localhost:8082/orders")
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		c.Data(resp.StatusCode, "application/json", body)
	})

	r.POST("/orders", func(c *gin.Context) {
		resp, err := http.Post("http://localhost:8082/orders", "application/json", c.Request.Body)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		c.Data(resp.StatusCode, "application/json", body)
	})

	r.DELETE("/orders/:id", func(c *gin.Context) {
		req, err := http.NewRequest("DELETE", "http://localhost:8082/orders/"+c.Param("id"), nil)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(500, gin.H{"error": err.Error()})
			return
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		c.Data(resp.StatusCode, "application/json", body)
	})
	r.GET("/status", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"status": "API Gateway is running"})
	})

	r.Run(":8080")
}
