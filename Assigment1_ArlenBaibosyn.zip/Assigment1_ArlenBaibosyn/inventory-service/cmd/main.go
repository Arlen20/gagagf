package main

import (
	"inventory-service/internal/delivery"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	delivery.RegisterInventoryRoutes(r)
	r.Run(":8081")
}
