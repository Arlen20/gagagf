package delivery

import (
	"inventory-service/internal/domain"
	"inventory-service/internal/repository"
	"net/http"

	"github.com/gin-gonic/gin"
)

var db = repository.InitDB()

func RegisterInventoryRoutes(r *gin.Engine) {
	db.AutoMigrate(&domain.Product{})
	r.GET("/products", GetProducts)
	r.GET("/products/:id", GetProductByID)
	r.POST("/products", CreateProduct)
	r.PATCH("/products/:id", UpdateProduct)
	r.DELETE("/products/:id", DeleteProduct)
}

func GetProducts(c *gin.Context) {
	var products []domain.Product
	db.Find(&products)
	c.JSON(http.StatusOK, products)
}

func GetProductByID(c *gin.Context) {
	id := c.Param("id")
	var product domain.Product
	if err := db.First(&product, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Product not found"})
		return
	}
	c.JSON(http.StatusOK, product)
}

func CreateProduct(c *gin.Context) {
	var p domain.Product
	if err := c.BindJSON(&p); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	db.Create(&p)
	c.JSON(http.StatusCreated, p)
}

func UpdateProduct(c *gin.Context) {
	id := c.Param("id")
	var product domain.Product
	if err := db.First(&product, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Product not found"})
		return
	}
	if err := c.BindJSON(&product); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	db.Save(&product)
	c.JSON(http.StatusOK, product)
}

func DeleteProduct(c *gin.Context) {
	id := c.Param("id")
	if err := db.Delete(&domain.Product{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"deleted": id})
}
