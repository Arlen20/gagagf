package domain

type Order struct {
	ID         uint   `json:"id" gorm:"primaryKey"`
	CustomerID string `json:"customer_id"`
	Status     string `json:"status"`
}
