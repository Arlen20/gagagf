package delivery

import (
	"net/http"
	"order-service/internal/domain"
	"order-service/internal/repository"

	"github.com/gin-gonic/gin"
)

var db = repository.InitDB()

func RegisterOrderRoutes(r *gin.Engine) {
	db.AutoMigrate(&domain.Order{})
	r.GET("/orders", GetOrders)
	r.GET("/orders/:id", GetOrderByID)
	r.POST("/orders", CreateOrder)
	r.PATCH("/orders/:id", UpdateOrder)
	r.DELETE("/orders/:id", DeleteOrder)
}

func GetOrders(c *gin.Context) {
	var orders []domain.Order
	db.Find(&orders)
	c.JSON(http.StatusOK, orders)
}

func GetOrderByID(c *gin.Context) {
	id := c.Param("id")
	var order domain.Order
	if err := db.First(&order, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Order not found"})
		return
	}
	c.JSON(http.StatusOK, order)
}

func CreateOrder(c *gin.Context) {
	var o domain.Order
	if err := c.BindJSON(&o); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	db.Create(&o)
	c.JSON(http.StatusCreated, o)
}

func UpdateOrder(c *gin.Context) {
	id := c.Param("id")
	var order domain.Order
	if err := db.First(&order, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Order not found"})
		return
	}
	if err := c.BindJSON(&order); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	db.Save(&order)
	c.JSON(http.StatusOK, order)
}

func DeleteOrder(c *gin.Context) {
	id := c.Param("id")
	if err := db.Delete(&domain.Order{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"deleted": id})
}
