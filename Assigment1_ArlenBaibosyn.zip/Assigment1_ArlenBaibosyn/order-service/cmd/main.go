package main

import (
	"order-service/internal/delivery"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	delivery.RegisterOrderRoutes(r)
	r.Run(":8082")
}
